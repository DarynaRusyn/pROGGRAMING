package com.example.workoutplanner;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.workoutplanner.database.AppDatabase;
import com.example.workoutplanner.database.DatabaseInitializer;
import com.example.workoutplanner.model.User;
import com.example.workoutplanner.ui.*;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ініціалізуємо базу даних з вправами
        DatabaseInitializer.populateDatabase(this);

        // ✅ Створюємо користувача за замовчуванням, якщо його немає
        createDefaultUserIfNeeded();

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        if (savedInstanceState == null) {
            loadFragment(new ExercisesFragment());
        }

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();

            if (itemId == R.id.nav_workouts) {
                selectedFragment = new WorkoutsFragment();
            } else if (itemId == R.id.nav_plans) {
                selectedFragment = new PlansFragment();
            } else if (itemId == R.id.nav_history) {
                selectedFragment = new HistoryFragment();
            } else if (itemId == R.id.nav_exercises) {
                selectedFragment = new ExercisesFragment();
            } else if (itemId == R.id.nav_profile) {
                selectedFragment = new ProfileFragment();
            }

            return loadFragment(selectedFragment);
        });
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    // ============================
    // 👤 КОРИСТУВАЧ ЗА ЗАМОВЧУВАННЯМ
    // ============================
    private void createDefaultUserIfNeeded() {
        SharedPreferences prefs =
                getSharedPreferences("WorkoutPlannerPrefs", MODE_PRIVATE);

        boolean userCreated =
                prefs.getBoolean("defaultUserCreated", false);

        if (!userCreated) {
            new Thread(() -> {
                AppDatabase db = AppDatabase.getInstance(this);

                User defaultUser = new User(
                        "Користувач",
                        "Підтримка форми",
                        "Початківець",
                        System.currentTimeMillis()
                );

                long userId = db.userDao().insert(defaultUser);

                prefs.edit()
                        .putLong("currentUserId", userId)
                        .putBoolean("defaultUserCreated", true)
                        .apply();

                android.util.Log.d(
                        "MainActivity",
                        "Default user created with ID: " + userId
                );
            }).start();
        }
    }
}
