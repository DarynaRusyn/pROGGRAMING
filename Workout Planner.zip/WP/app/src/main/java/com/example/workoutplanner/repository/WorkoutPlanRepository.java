package com.example.workoutplanner.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.workoutplanner.dao.WorkoutPlanDao;
import com.example.workoutplanner.database.AppDatabase;
import com.example.workoutplanner.model.WorkoutPlan;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WorkoutPlanRepository {

    private WorkoutPlanDao planDao;
    private LiveData<List<WorkoutPlan>> allPlans;
    private ExecutorService executorService;

    public WorkoutPlanRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        planDao = database.workoutPlanDao();
        allPlans = planDao.getAllPlans();
        executorService = Executors.newSingleThreadExecutor();
    }

    public void insert(WorkoutPlan plan) {
        executorService.execute(() -> planDao.insert(plan));
    }

    public void update(WorkoutPlan plan) {
        executorService.execute(() -> planDao.update(plan));
    }

    public void delete(WorkoutPlan plan) {
        executorService.execute(() -> planDao.delete(plan));
    }

    public LiveData<List<WorkoutPlan>> getAllPlans() {
        return allPlans;
    }

    public LiveData<List<WorkoutPlan>> getPlansByUserId(int userId) {
        return planDao.getPlansByUserId(userId);
    }

    public LiveData<WorkoutPlan> getPlanById(int planId) {
        return planDao.getPlanById(planId);
    }

    public LiveData<WorkoutPlan> getActivePlan(int userId) {
        return planDao.getActivePlan(userId);
    }

    public void deactivateAllPlans(int userId) {
        executorService.execute(() -> planDao.deactivateAllPlans(userId));
    }
}