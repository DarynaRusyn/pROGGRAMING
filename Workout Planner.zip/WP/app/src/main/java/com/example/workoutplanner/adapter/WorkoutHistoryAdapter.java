package com.example.workoutplanner.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutplanner.R;
import com.example.workoutplanner.model.WorkoutHistory;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WorkoutHistoryAdapter extends RecyclerView.Adapter<WorkoutHistoryAdapter.HistoryHolder> {

    private List<WorkoutHistory> historyList = new ArrayList<>();
    private OnItemClickListener listener;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());

    @NonNull
    @Override
    public HistoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_history, parent, false);
        return new HistoryHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryHolder holder, int position) {
        WorkoutHistory currentHistory = historyList.get(position);
        holder.textViewName.setText(currentHistory.getWorkoutName());
        holder.textViewDate.setText(dateFormat.format(new Date(currentHistory.getCompletedDate())));
        holder.textViewDuration.setText(currentHistory.getDurationMinutes() + " хв");

        if (currentHistory.getNotes() != null && !currentHistory.getNotes().isEmpty()) {
            holder.textViewNotes.setVisibility(View.VISIBLE);
            holder.textViewNotes.setText(currentHistory.getNotes());
        } else {
            holder.textViewNotes.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    public void setHistory(List<WorkoutHistory> history) {
        this.historyList = history;
        notifyDataSetChanged();
    }

    public WorkoutHistory getHistoryAt(int position) {
        return historyList.get(position);
    }

    class HistoryHolder extends RecyclerView.ViewHolder {
        private TextView textViewName;
        private TextView textViewDate;
        private TextView textViewDuration;
        private TextView textViewNotes;

        public HistoryHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_view_history_name);
            textViewDate = itemView.findViewById(R.id.text_view_history_date);
            textViewDuration = itemView.findViewById(R.id.text_view_history_duration);
            textViewNotes = itemView.findViewById(R.id.text_view_history_notes);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(historyList.get(position));
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(WorkoutHistory history);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}