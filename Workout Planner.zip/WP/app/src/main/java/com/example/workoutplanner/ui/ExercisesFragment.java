package com.example.workoutplanner.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutplanner.R;
import com.example.workoutplanner.adapter.ExerciseAdapter;
import com.example.workoutplanner.model.Exercise;
import com.example.workoutplanner.viewmodel.ExerciseViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ExercisesFragment extends Fragment {

    private RecyclerView recyclerView;
    private ExerciseAdapter adapter;
    private ExerciseViewModel viewModel;
    private FloatingActionButton fabAdd;
    private static final int ADD_EXERCISE_REQUEST = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exercises, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewExercises);
        fabAdd = view.findViewById(R.id.fabAddExercise);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ExerciseAdapter();
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(ExerciseViewModel.class);
        viewModel.getAllExercises().observe(getViewLifecycleOwner(), exercises -> {
            adapter.setExercises(exercises);
        });

        adapter.setOnItemClickListener(exercise -> {
            Toast.makeText(getContext(),
                    exercise.getExerciseName() + "\n" + exercise.getExerciseDescription(),
                    Toast.LENGTH_LONG).show();
        });

        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), AddExerciseActivity.class);
            startActivityForResult(intent, ADD_EXERCISE_REQUEST);
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_EXERCISE_REQUEST && resultCode == getActivity().RESULT_OK && data != null) {
            String name = data.getStringExtra(AddExerciseActivity.EXTRA_EXERCISE_NAME);
            String description = data.getStringExtra(AddExerciseActivity.EXTRA_EXERCISE_DESCRIPTION);
            String muscleGroup = data.getStringExtra(AddExerciseActivity.EXTRA_MUSCLE_GROUP);
            String equipment = data.getStringExtra(AddExerciseActivity.EXTRA_EQUIPMENT);
            String difficulty = data.getStringExtra(AddExerciseActivity.EXTRA_DIFFICULTY);

            Exercise exercise = new Exercise(name, description, muscleGroup,
                    equipment, difficulty, "", true);

            viewModel.insert(exercise);
            Toast.makeText(getContext(), "Вправу додано!", Toast.LENGTH_SHORT).show();
        }
    }
}