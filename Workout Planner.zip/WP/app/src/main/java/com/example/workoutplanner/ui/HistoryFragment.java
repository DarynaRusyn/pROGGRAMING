package com.example.workoutplanner.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutplanner.R;
import com.example.workoutplanner.adapter.WorkoutHistoryAdapter;
import com.example.workoutplanner.viewmodel.WorkoutHistoryViewModel;

public class HistoryFragment extends Fragment {

    private RecyclerView recyclerView;
    private WorkoutHistoryAdapter adapter;
    private WorkoutHistoryViewModel viewModel;
    private TextView textEmptyView;
    private TextView textTotalWorkouts;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewHistory);
        textEmptyView = view.findViewById(R.id.textEmptyHistory);
        textTotalWorkouts = view.findViewById(R.id.textTotalWorkouts);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new WorkoutHistoryAdapter();
        adapter.setOnItemClickListener(history -> {
            Toast.makeText(getContext(),
                    history.getWorkoutName() + "\n" +
                            "Тривалість: " + history.getDurationMinutes() + " хв\n" +
                            "Нотатки: " + history.getNotes(),
                    Toast.LENGTH_LONG).show();
        });
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(WorkoutHistoryViewModel.class);
        viewModel.getAllHistory().observe(getViewLifecycleOwner(), history -> {
            adapter.setHistory(history);

            if (history == null || history.isEmpty()) {
                recyclerView.setVisibility(View.GONE);
                textEmptyView.setVisibility(View.VISIBLE);
                textTotalWorkouts.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                textEmptyView.setVisibility(View.GONE);
                textTotalWorkouts.setVisibility(View.VISIBLE);
                textTotalWorkouts.setText("Всього тренувань: " + history.size());
            }
        });

        return view;
    }
}