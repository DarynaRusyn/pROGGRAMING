package com.example.workoutplanner.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.workoutplanner.dao.WorkoutDao;
import com.example.workoutplanner.database.AppDatabase;
import com.example.workoutplanner.model.Workout;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WorkoutRepository {

    private WorkoutDao workoutDao;
    private LiveData<List<Workout>> allWorkouts;
    private ExecutorService executorService;

    public WorkoutRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        workoutDao = database.workoutDao();
        allWorkouts = workoutDao.getAllWorkouts();
        executorService = Executors.newSingleThreadExecutor();
    }

    public void insert(Workout workout) {
        executorService.execute(() -> workoutDao.insert(workout));
    }

    public void update(Workout workout) {
        executorService.execute(() -> workoutDao.update(workout));
    }

    public void delete(Workout workout) {
        executorService.execute(() -> workoutDao.delete(workout));
    }

    public LiveData<List<Workout>> getAllWorkouts() {
        return allWorkouts;
    }

    public LiveData<List<Workout>> getWorkoutsByUserId(int userId) {
        return workoutDao.getWorkoutsByUserId(userId);
    }

    public LiveData<Workout> getWorkoutById(int workoutId) {
        return workoutDao.getWorkoutById(workoutId);
    }
}