package com.example.workoutplanner.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.example.workoutplanner.R;
import com.example.workoutplanner.viewmodel.UserViewModel;
import com.example.workoutplanner.viewmodel.WorkoutHistoryViewModel;

import static android.content.Context.MODE_PRIVATE;

public class ProfileFragment extends Fragment {

    private TextView textUserName, textUserGoal, textUserLevel, textTotalWorkouts;
    private Button btnEditProfile;
    private UserViewModel userViewModel;
    private WorkoutHistoryViewModel historyViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        textUserName = view.findViewById(R.id.textUserName);
        textUserGoal = view.findViewById(R.id.textUserGoal);
        textUserLevel = view.findViewById(R.id.textUserLevel);
        textTotalWorkouts = view.findViewById(R.id.textTotalWorkouts);
        btnEditProfile = view.findViewById(R.id.btnEditProfile);

        userViewModel = new ViewModelProvider(requireActivity()).get(UserViewModel.class);
        historyViewModel = new ViewModelProvider(requireActivity()).get(WorkoutHistoryViewModel.class);

        loadStatistics();

        btnEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), EditProfileActivity.class);
            startActivity(intent);
        });

        return view;
    }

    private void loadUserProfile() {
        userViewModel.getCurrentUser().observe(getViewLifecycleOwner(), user -> {
            if (user != null) {
                // Користувач існує - показуємо дані
                textUserName.setText(user.getUserName());
                textUserGoal.setText("Мета: " + user.getUserGoal());
                textUserLevel.setText("Рівень: " + user.getExperienceLevel());
                btnEditProfile.setText("Редагувати профіль");
            } else {
                // Користувача немає - показуємо заглушку
                textUserName.setText("Профіль не налаштований");
                textUserGoal.setText("Мета: Не вказана");
                textUserLevel.setText("Рівень: Не вказаний");
                btnEditProfile.setText("Створити профіль");
            }
        });
    }

    private void loadStatistics() {
        SharedPreferences prefs = requireContext().getSharedPreferences("WorkoutPlannerPrefs", MODE_PRIVATE);
        long userId = prefs.getLong("currentUserId", 1);

        historyViewModel.getTotalWorkoutsCount((int)userId).observe(getViewLifecycleOwner(), count -> {
            if (count != null) {
                textTotalWorkouts.setText("Виконано тренувань: " + count);
            } else {
                textTotalWorkouts.setText("Виконано тренувань: 0");
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadUserProfile();
    }
}