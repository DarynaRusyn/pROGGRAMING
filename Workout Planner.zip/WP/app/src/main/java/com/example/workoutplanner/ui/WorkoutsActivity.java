package com.example.workoutplanner.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutplanner.MainActivity;  // ← ВИПРАВЛЕНО
import com.example.workoutplanner.R;
import com.example.workoutplanner.adapter.WorkoutAdapter;
import com.example.workoutplanner.databinding.ActivityWorkoutsBinding;
import com.example.workoutplanner.viewmodel.WorkoutViewModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class WorkoutsActivity extends AppCompatActivity {

    private ActivityWorkoutsBinding binding;
    private WorkoutViewModel workoutViewModel;
    private WorkoutAdapter adapter;
    private static final int ADD_WORKOUT_REQUEST = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWorkoutsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Налаштування Toolbar
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Тренування");
        }

        // RecyclerView
        RecyclerView recyclerView = binding.recyclerViewWorkouts;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        adapter = new WorkoutAdapter();
        recyclerView.setAdapter(adapter);

        // ViewModel
        workoutViewModel = new ViewModelProvider(this).get(WorkoutViewModel.class);
        workoutViewModel.getAllWorkouts().observe(this, workouts -> {
            adapter.setWorkouts(workouts);
        });

        // FAB
        binding.fabAddWorkout.setOnClickListener(view -> {
            Intent intent = new Intent(WorkoutsActivity.this, AddWorkoutActivity.class);
            startActivityForResult(intent, ADD_WORKOUT_REQUEST);
        });

        // Клік на тренування
        adapter.setOnItemClickListener(workout -> {
            Toast.makeText(this, "Вибрано: " + workout.getWorkoutName(),
                    Toast.LENGTH_SHORT).show();
        });

        // Bottom Navigation
        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNav = binding.bottomNavigation;
        bottomNav.setSelectedItemId(R.id.nav_workouts);

        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_workouts) {
                return true;
            } else if (itemId == R.id.nav_exercises) {
                startActivity(new Intent(this, MainActivity.class));
                finish();
                return true;
            } else if (itemId == R.id.nav_plans) {
                Toast.makeText(this, "Плани (в розробці)", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.nav_history) {
                Toast.makeText(this, "Історія (в розробці)", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_WORKOUT_REQUEST && resultCode == RESULT_OK) {
            Toast.makeText(this, "Тренування додано!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}