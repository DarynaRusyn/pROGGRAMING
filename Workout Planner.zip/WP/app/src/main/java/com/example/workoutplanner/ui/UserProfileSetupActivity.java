package com.example.workoutplanner.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.workoutplanner.MainActivity;
import com.example.workoutplanner.R;
import com.example.workoutplanner.database.AppDatabase;
import com.example.workoutplanner.model.User;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import java.util.concurrent.Executors;

public class UserProfileSetupActivity extends AppCompatActivity {
    private TextInputEditText etUserName;
    private MaterialAutoCompleteTextView spinnerGoal, spinnerLevel;
    private MaterialButton btnComplete;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile_setup);

        database = AppDatabase.getInstance(this);

        etUserName = findViewById(R.id.etUserName);
        spinnerGoal = findViewById(R.id.spinnerGoal);
        spinnerLevel = findViewById(R.id.spinnerLevel);
        btnComplete = findViewById(R.id.btnComplete);

        setupSpinners();

        btnComplete.setOnClickListener(v -> saveUserProfile());
    }

    private void setupSpinners() {
        String[] goals = getResources().getStringArray(R.array.user_goals);
        ArrayAdapter<String> goalAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, goals);
        spinnerGoal.setAdapter(goalAdapter);

        String[] levels = getResources().getStringArray(R.array.experience_levels);
        ArrayAdapter<String> levelAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, levels);
        spinnerLevel.setAdapter(levelAdapter);
    }

    private void saveUserProfile() {
        String userName = etUserName.getText().toString().trim();
        String goal = spinnerGoal.getText().toString().trim();
        String level = spinnerLevel.getText().toString().trim();

        Log.d("UserProfileSetup", "Attempting to save profile");
        Log.d("UserProfileSetup", "Name: " + userName);
        Log.d("UserProfileSetup", "Goal: " + goal);
        Log.d("UserProfileSetup", "Level: " + level);

        if (userName.isEmpty()) {
            etUserName.setError("Введіть ім'я");
            return;
        }

        if (goal.isEmpty()) {
            Toast.makeText(this, "Оберіть мету тренувань", Toast.LENGTH_SHORT).show();
            return;
        }

        if (level.isEmpty()) {
            Toast.makeText(this, "Оберіть рівень підготовки", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User(userName, goal, level, System.currentTimeMillis());

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                long userId = database.userDao().insert(user);
                Log.d("UserProfileSetup", "User inserted with ID: " + userId);

                SharedPreferences prefs = getSharedPreferences("WorkoutPlannerPrefs", MODE_PRIVATE);
                prefs.edit()
                        .putLong("currentUserId", userId)
                        .putBoolean("profileSetupCompleted", true)
                        .apply();

                Log.d("UserProfileSetup", "SharedPreferences saved");

                runOnUiThread(() -> {
                    Toast.makeText(this, "Профіль створено!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(UserProfileSetupActivity.this, MainActivity.class));
                    finish();
                });
            } catch (Exception e) {
                Log.e("UserProfileSetup", "Error saving user", e);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Помилка: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }
}