package com.example.workoutplanner.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;

@Entity(tableName = "exercises")
public class Exercise {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "exercise_id")
    private int exerciseId;

    @ColumnInfo(name = "exercise_name")
    private String exerciseName;

    @ColumnInfo(name = "exercise_description")
    private String exerciseDescription;

    @ColumnInfo(name = "muscle_group")
    private String muscleGroup;

    @ColumnInfo(name = "equipment")
    private String equipment;

    @ColumnInfo(name = "difficulty_level")
    private String difficultyLevel;

    @ColumnInfo(name = "video_url")
    private String videoUrl;

    @ColumnInfo(name = "is_custom")
    private boolean isCustom;

    public Exercise(String exerciseName, String exerciseDescription,
                    String muscleGroup, String equipment, String difficultyLevel,
                    String videoUrl, boolean isCustom) {
        this.exerciseName = exerciseName;
        this.exerciseDescription = exerciseDescription;
        this.muscleGroup = muscleGroup;
        this.equipment = equipment;
        this.difficultyLevel = difficultyLevel;
        this.videoUrl = videoUrl;
        this.isCustom = isCustom;
    }

    public int getExerciseId() { return exerciseId; }
    public void setExerciseId(int exerciseId) { this.exerciseId = exerciseId; }

    public String getExerciseName() { return exerciseName; }
    public void setExerciseName(String exerciseName) {
        this.exerciseName = exerciseName;
    }

    public String getExerciseDescription() { return exerciseDescription; }
    public void setExerciseDescription(String exerciseDescription) {
        this.exerciseDescription = exerciseDescription;
    }

    public String getMuscleGroup() { return muscleGroup; }
    public void setMuscleGroup(String muscleGroup) {
        this.muscleGroup = muscleGroup;
    }

    public String getEquipment() { return equipment; }
    public void setEquipment(String equipment) { this.equipment = equipment; }

    public String getDifficultyLevel() { return difficultyLevel; }
    public void setDifficultyLevel(String difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

    public String getVideoUrl() { return videoUrl; }
    public void setVideoUrl(String videoUrl) { this.videoUrl = videoUrl; }

    public boolean isCustom() { return isCustom; }
    public void setCustom(boolean custom) { isCustom = custom; }
}