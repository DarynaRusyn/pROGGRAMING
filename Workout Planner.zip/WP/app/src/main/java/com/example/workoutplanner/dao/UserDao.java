package com.example.workoutplanner.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.example.workoutplanner.model.User;
import java.util.List;

@Dao
public interface UserDao {

    @Insert
    long insert(User user);

    @Update
    void update(User user);

    @Delete
    void delete(User user);

    @Query("SELECT * FROM users ORDER BY created_date DESC")
    LiveData<List<User>> getAllUsers();

    @Query("SELECT * FROM users WHERE user_id = :userId")
    LiveData<User> getUserById(int userId);

    @Query("SELECT * FROM users LIMIT 1")
    LiveData<User> getCurrentUser();
}