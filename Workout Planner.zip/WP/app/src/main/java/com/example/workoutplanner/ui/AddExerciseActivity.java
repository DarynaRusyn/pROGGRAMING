package com.example.workoutplanner.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.workoutplanner.R;
import com.google.android.material.textfield.TextInputEditText;

public class AddExerciseActivity extends AppCompatActivity {

    public static final String EXTRA_EXERCISE_NAME = "com.example.workoutplanner.EXERCISE_NAME";
    public static final String EXTRA_EXERCISE_DESCRIPTION = "com.example.workoutplanner.EXERCISE_DESCRIPTION";
    public static final String EXTRA_MUSCLE_GROUP = "com.example.workoutplanner.MUSCLE_GROUP";
    public static final String EXTRA_EQUIPMENT = "com.example.workoutplanner.EQUIPMENT";
    public static final String EXTRA_DIFFICULTY = "com.example.workoutplanner.DIFFICULTY";

    private TextInputEditText editTextName;
    private TextInputEditText editTextDescription;
    private Spinner spinnerMuscleGroup;
    private Spinner spinnerEquipment;
    private Spinner spinnerDifficulty;
    private Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_exercise);

        editTextName = findViewById(R.id.edit_text_name);
        editTextDescription = findViewById(R.id.edit_text_description);
        spinnerMuscleGroup = findViewById(R.id.spinner_muscle_group);
        spinnerEquipment = findViewById(R.id.spinner_equipment);
        spinnerDifficulty = findViewById(R.id.spinner_difficulty);
        buttonSave = findViewById(R.id.button_save);

        ArrayAdapter<CharSequence> muscleAdapter = ArrayAdapter.createFromResource(
                this, R.array.muscle_groups, android.R.layout.simple_spinner_item);
        muscleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMuscleGroup.setAdapter(muscleAdapter);

        ArrayAdapter<CharSequence> equipmentAdapter = ArrayAdapter.createFromResource(
                this, R.array.equipment_types, android.R.layout.simple_spinner_item);
        equipmentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEquipment.setAdapter(equipmentAdapter);

        ArrayAdapter<CharSequence> difficultyAdapter = ArrayAdapter.createFromResource(
                this, R.array.difficulty_levels, android.R.layout.simple_spinner_item);
        difficultyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDifficulty.setAdapter(difficultyAdapter);

        buttonSave.setOnClickListener(v -> saveExercise());

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Додати вправу");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void saveExercise() {
        String name = editTextName.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String muscleGroup = spinnerMuscleGroup.getSelectedItem().toString();
        String equipment = spinnerEquipment.getSelectedItem().toString();
        String difficulty = spinnerDifficulty.getSelectedItem().toString();

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Введіть назву вправи", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(description)) {
            description = "Опис відсутній";
        }

        android.content.Intent resultIntent = new android.content.Intent();
        resultIntent.putExtra(EXTRA_EXERCISE_NAME, name);
        resultIntent.putExtra(EXTRA_EXERCISE_DESCRIPTION, description);
        resultIntent.putExtra(EXTRA_MUSCLE_GROUP, muscleGroup);
        resultIntent.putExtra(EXTRA_EQUIPMENT, equipment);
        resultIntent.putExtra(EXTRA_DIFFICULTY, difficulty);

        setResult(RESULT_OK, resultIntent);
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}