package com.example.workoutplanner.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.workoutplanner.model.User;
import com.example.workoutplanner.repository.UserRepository;

public class UserViewModel extends AndroidViewModel {

    private UserRepository repository;
    private LiveData<User> currentUser;

    public UserViewModel(@NonNull Application application) {
        super(application);
        repository = new UserRepository(application);
        currentUser = repository.getCurrentUser();
    }

    public void insert(User user) {
        repository.insert(user);
    }

    public void update(User user) {
        repository.update(user);
    }

    public LiveData<User> getCurrentUser() {
        return currentUser;
    }

    public LiveData<User> getUserById(int userId) {
        return repository.getUserById(userId);
    }
}