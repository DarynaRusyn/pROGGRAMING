package com.example.workoutplanner.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.workoutplanner.R;
import com.example.workoutplanner.model.WorkoutPlan;
import com.example.workoutplanner.viewmodel.WorkoutPlanViewModel;
import com.google.android.material.textfield.TextInputEditText;

public class AddWorkoutPlanActivity extends AppCompatActivity {

    private TextInputEditText editTextName;
    private TextInputEditText editTextDescription;
    private TextInputEditText editTextWeeks;
    private TextInputEditText editTextDays;
    private Button buttonSave;
    private WorkoutPlanViewModel planViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_workout_plan);

        editTextName = findViewById(R.id.edit_text_plan_name);
        editTextDescription = findViewById(R.id.edit_text_plan_description);
        editTextWeeks = findViewById(R.id.edit_text_weeks);
        editTextDays = findViewById(R.id.edit_text_days);
        buttonSave = findViewById(R.id.button_save_plan);

        planViewModel = new ViewModelProvider(this).get(WorkoutPlanViewModel.class);

        buttonSave.setOnClickListener(v -> savePlan());

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Додати план");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void savePlan() {
        String name = editTextName.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String weeksStr = editTextWeeks.getText().toString().trim();
        String daysStr = editTextDays.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Введіть назву плану", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(weeksStr)) {
            Toast.makeText(this, "Введіть тривалість", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(daysStr)) {
            Toast.makeText(this, "Введіть кількість днів", Toast.LENGTH_SHORT).show();
            return;
        }

        int weeks = Integer.parseInt(weeksStr);
        int days = Integer.parseInt(daysStr);

        if (TextUtils.isEmpty(description)) {
            description = "Опис відсутній";
        }

        WorkoutPlan plan = new WorkoutPlan(name, description, weeks, days,
                System.currentTimeMillis(), 1, false);

        planViewModel.insert(plan);

        setResult(RESULT_OK);
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}