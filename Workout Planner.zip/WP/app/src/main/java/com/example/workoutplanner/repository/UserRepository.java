package com.example.workoutplanner.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.workoutplanner.dao.UserDao;
import com.example.workoutplanner.database.AppDatabase;
import com.example.workoutplanner.model.User;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UserRepository {

    private UserDao userDao;
    private LiveData<User> currentUser;
    private ExecutorService executorService;

    public UserRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        userDao = database.userDao();
        currentUser = userDao.getCurrentUser();
        executorService = Executors.newSingleThreadExecutor();
    }

    public void insert(User user) {
        executorService.execute(() -> userDao.insert(user));
    }

    public void update(User user) {
        executorService.execute(() -> userDao.update(user));
    }

    public LiveData<User> getCurrentUser() {
        return currentUser;
    }

    public LiveData<User> getUserById(int userId) {
        return userDao.getUserById(userId);
    }
}