package com.example.workoutplanner.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.workoutplanner.R;
import com.example.workoutplanner.model.Workout;
import com.example.workoutplanner.viewmodel.WorkoutViewModel;
import com.google.android.material.textfield.TextInputEditText;

public class AddWorkoutActivity extends AppCompatActivity {

    private TextInputEditText editTextName;
    private TextInputEditText editTextDescription;
    private TextInputEditText editTextDuration;
    private Spinner spinnerDifficulty;
    private Button buttonSave;
    private WorkoutViewModel workoutViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_workout);

        editTextName = findViewById(R.id.edit_text_workout_name);
        editTextDescription = findViewById(R.id.edit_text_workout_description);
        editTextDuration = findViewById(R.id.edit_text_duration);
        spinnerDifficulty = findViewById(R.id.spinner_workout_difficulty);
        buttonSave = findViewById(R.id.button_save_workout);

        workoutViewModel = new ViewModelProvider(this).get(WorkoutViewModel.class);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.difficulty_levels, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDifficulty.setAdapter(adapter);

        buttonSave.setOnClickListener(v -> saveWorkout());

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Додати тренування");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void saveWorkout() {
        String name = editTextName.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String durationStr = editTextDuration.getText().toString().trim();
        String difficulty = spinnerDifficulty.getSelectedItem().toString();

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Введіть назву тренування", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(durationStr)) {
            Toast.makeText(this, "Введіть тривалість", Toast.LENGTH_SHORT).show();
            return;
        }

        int duration = Integer.parseInt(durationStr);

        if (TextUtils.isEmpty(description)) {
            description = "Опис відсутній";
        }

        Workout workout = new Workout(name, description, duration, difficulty,
                System.currentTimeMillis(), 1);

        workoutViewModel.insert(workout);

        setResult(RESULT_OK);
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}