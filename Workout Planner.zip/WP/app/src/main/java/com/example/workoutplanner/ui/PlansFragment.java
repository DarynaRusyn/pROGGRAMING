package com.example.workoutplanner.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutplanner.R;
import com.example.workoutplanner.adapter.WorkoutPlanAdapter;
import com.example.workoutplanner.viewmodel.WorkoutPlanViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class PlansFragment extends Fragment {

    private RecyclerView recyclerView;
    private WorkoutPlanAdapter adapter;
    private WorkoutPlanViewModel viewModel;
    private FloatingActionButton fabAdd;
    private TextView textEmptyView;
    private static final int ADD_PLAN_REQUEST = 3;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_plans, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewPlans);
        fabAdd = view.findViewById(R.id.fabAddPlan);
        textEmptyView = view.findViewById(R.id.textEmptyPlans);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new WorkoutPlanAdapter();
        adapter.setOnItemClickListener(plan -> {
            Toast.makeText(getContext(),
                    "План: " + plan.getPlanName() + "\n" +
                            plan.getDurationWeeks() + " тижнів, " +
                            plan.getDaysPerWeek() + " днів на тиждень",
                    Toast.LENGTH_LONG).show();
        });
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(WorkoutPlanViewModel.class);
        viewModel.getAllPlans().observe(getViewLifecycleOwner(), plans -> {
            adapter.setPlans(plans);

            if (plans == null || plans.isEmpty()) {
                recyclerView.setVisibility(View.GONE);
                textEmptyView.setVisibility(View.VISIBLE);
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                textEmptyView.setVisibility(View.GONE);
            }
        });

        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), AddWorkoutPlanActivity.class);
            startActivityForResult(intent, ADD_PLAN_REQUEST);
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_PLAN_REQUEST && resultCode == getActivity().RESULT_OK) {
            Toast.makeText(getContext(), "План додано!", Toast.LENGTH_SHORT).show();
        }
    }
}