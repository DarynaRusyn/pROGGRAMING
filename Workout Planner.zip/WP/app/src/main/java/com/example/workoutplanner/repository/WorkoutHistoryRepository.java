package com.example.workoutplanner.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.workoutplanner.dao.WorkoutHistoryDao;
import com.example.workoutplanner.database.AppDatabase;
import com.example.workoutplanner.model.WorkoutHistory;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WorkoutHistoryRepository {

    private WorkoutHistoryDao historyDao;
    private LiveData<List<WorkoutHistory>> allHistory;
    private ExecutorService executorService;

    public WorkoutHistoryRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        historyDao = database.workoutHistoryDao();
        allHistory = historyDao.getAllHistory();
        executorService = Executors.newSingleThreadExecutor();
    }

    public void insert(WorkoutHistory history) {
        executorService.execute(() -> historyDao.insert(history));
    }

    public void update(WorkoutHistory history) {
        executorService.execute(() -> historyDao.update(history));
    }

    public void delete(WorkoutHistory history) {
        executorService.execute(() -> historyDao.delete(history));
    }

    public LiveData<List<WorkoutHistory>> getAllHistory() {
        return allHistory;
    }

    public LiveData<List<WorkoutHistory>> getHistoryByUserId(int userId) {
        return historyDao.getHistoryByUserId(userId);
    }

    public LiveData<WorkoutHistory> getHistoryById(int historyId) {
        return historyDao.getHistoryById(historyId);
    }

    public LiveData<Integer> getTotalWorkoutsCount(int userId) {
        return historyDao.getTotalWorkoutsCount(userId);
    }
}