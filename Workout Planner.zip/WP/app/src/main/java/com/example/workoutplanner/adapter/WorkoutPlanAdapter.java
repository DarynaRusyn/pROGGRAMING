package com.example.workoutplanner.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutplanner.R;
import com.example.workoutplanner.model.WorkoutPlan;
import java.util.ArrayList;
import java.util.List;

public class WorkoutPlanAdapter extends RecyclerView.Adapter<WorkoutPlanAdapter.PlanHolder> {

    private List<WorkoutPlan> plans = new ArrayList<>();
    private OnItemClickListener listener;

    @NonNull
    @Override
    public PlanHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_plan, parent, false);
        return new PlanHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PlanHolder holder, int position) {
        WorkoutPlan currentPlan = plans.get(position);
        holder.textViewName.setText(currentPlan.getPlanName());
        holder.textViewDescription.setText(currentPlan.getPlanDescription());
        holder.textViewDuration.setText(currentPlan.getDurationWeeks() + " тижнів");
        holder.textViewFrequency.setText(currentPlan.getDaysPerWeek() + " днів/тиждень");

        if (currentPlan.isActive()) {
            holder.textViewStatus.setVisibility(View.VISIBLE);
            holder.textViewStatus.setText("Активний");
        } else {
            holder.textViewStatus.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return plans.size();
    }

    public void setPlans(List<WorkoutPlan> plans) {
        this.plans = plans;
        notifyDataSetChanged();
    }

    public WorkoutPlan getPlanAt(int position) {
        return plans.get(position);
    }

    class PlanHolder extends RecyclerView.ViewHolder {
        private TextView textViewName;
        private TextView textViewDescription;
        private TextView textViewDuration;
        private TextView textViewFrequency;
        private TextView textViewStatus;

        public PlanHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_view_plan_name);
            textViewDescription = itemView.findViewById(R.id.text_view_plan_description);
            textViewDuration = itemView.findViewById(R.id.text_view_plan_duration);
            textViewFrequency = itemView.findViewById(R.id.text_view_plan_frequency);
            textViewStatus = itemView.findViewById(R.id.text_view_plan_status);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(plans.get(position));
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(WorkoutPlan plan);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}