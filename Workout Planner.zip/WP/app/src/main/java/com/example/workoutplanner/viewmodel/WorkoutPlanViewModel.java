package com.example.workoutplanner.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.workoutplanner.model.WorkoutPlan;
import com.example.workoutplanner.repository.WorkoutPlanRepository;
import java.util.List;

public class WorkoutPlanViewModel extends AndroidViewModel {

    private WorkoutPlanRepository repository;
    private LiveData<List<WorkoutPlan>> allPlans;

    public WorkoutPlanViewModel(@NonNull Application application) {
        super(application);
        repository = new WorkoutPlanRepository(application);
        allPlans = repository.getAllPlans();
    }

    public void insert(WorkoutPlan plan) {
        repository.insert(plan);
    }

    public void update(WorkoutPlan plan) {
        repository.update(plan);
    }

    public void delete(WorkoutPlan plan) {
        repository.delete(plan);
    }

    public LiveData<List<WorkoutPlan>> getAllPlans() {
        return allPlans;
    }

    public LiveData<List<WorkoutPlan>> getPlansByUserId(int userId) {
        return repository.getPlansByUserId(userId);
    }

    public LiveData<WorkoutPlan> getPlanById(int planId) {
        return repository.getPlanById(planId);
    }

    public LiveData<WorkoutPlan> getActivePlan(int userId) {
        return repository.getActivePlan(userId);
    }

    public void deactivateAllPlans(int userId) {
        repository.deactivateAllPlans(userId);
    }
}