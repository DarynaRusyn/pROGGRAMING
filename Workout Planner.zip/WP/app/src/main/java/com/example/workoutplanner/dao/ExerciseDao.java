package com.example.workoutplanner.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.example.workoutplanner.model.Exercise;
import java.util.List;

@Dao
public interface ExerciseDao {

    @Insert
    long insert(Exercise exercise);

    @Update
    void update(Exercise exercise);

    @Delete
    void delete(Exercise exercise);

    @Query("SELECT * FROM exercises ORDER BY exercise_name ASC")
    LiveData<List<Exercise>> getAllExercises();

    @Query("SELECT * FROM exercises WHERE muscle_group = :muscleGroup")
    LiveData<List<Exercise>> getExercisesByMuscleGroup(String muscleGroup);

    @Query("SELECT * FROM exercises WHERE equipment = :equipment")
    LiveData<List<Exercise>> getExercisesByEquipment(String equipment);

    @Query("SELECT * FROM exercises WHERE exercise_id = :exerciseId")
    LiveData<Exercise> getExerciseById(int exerciseId);

    @Query("SELECT COUNT(*) FROM exercises")
    int getExerciseCount();
}