package com.example.workoutplanner.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.example.workoutplanner.model.WorkoutHistory;
import java.util.List;

@Dao
public interface WorkoutHistoryDao {

    @Insert
    long insert(WorkoutHistory history);

    @Update
    void update(WorkoutHistory history);

    @Delete
    void delete(WorkoutHistory history);

    @Query("SELECT * FROM workout_history ORDER BY completed_date DESC")
    LiveData<List<WorkoutHistory>> getAllHistory();

    @Query("SELECT * FROM workout_history WHERE user_id = :userId ORDER BY completed_date DESC")
    LiveData<List<WorkoutHistory>> getHistoryByUserId(int userId);

    @Query("SELECT * FROM workout_history WHERE history_id = :historyId")
    LiveData<WorkoutHistory> getHistoryById(int historyId);

    @Query("SELECT COUNT(*) FROM workout_history WHERE user_id = :userId")
    LiveData<Integer> getTotalWorkoutsCount(int userId);
}