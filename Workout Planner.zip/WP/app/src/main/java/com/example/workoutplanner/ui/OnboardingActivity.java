package com.example.workoutplanner.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import com.example.workoutplanner.R;
import com.example.workoutplanner.adapter.OnboardingAdapter;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import java.util.ArrayList;
import java.util.List;

public class OnboardingActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TabLayout tabLayout;
    private Button btnNext, btnSkip;
    private OnboardingAdapter adapter;
    private int currentPage = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        viewPager = findViewById(R.id.viewPagerOnboarding);
        tabLayout = findViewById(R.id.tabLayoutOnboarding);
        btnNext = findViewById(R.id.btnNext);
        btnSkip = findViewById(R.id.btnSkip);

        setupOnboardingItems();

        btnNext.setOnClickListener(v -> {
            if (currentPage < 2) {
                viewPager.setCurrentItem(currentPage + 1);
            } else {
                finishOnboarding();
            }
        });

        btnSkip.setOnClickListener(v -> finishOnboarding());

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                currentPage = position;
                if (position == 2) {
                    btnNext.setText("Почати");
                    btnSkip.setVisibility(View.GONE);
                } else {
                    btnNext.setText("Далі");
                    btnSkip.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void setupOnboardingItems() {
        List<OnboardingItem> items = new ArrayList<>();
        items.add(new OnboardingItem(
                R.drawable.ic_launcher_foreground,
                "Плануйте тренування",
                "Створюйте персоналізовані плани тренувань відповідно до ваших цілей"
        ));
        items.add(new OnboardingItem(
                R.drawable.ic_launcher_foreground,
                "База вправ",
                "Доступ до великої бази вправ з описом техніки виконання"
        ));
        items.add(new OnboardingItem(
                R.drawable.ic_launcher_foreground,
                "Відстежуйте прогрес",
                "Ведіть журнал тренувань та аналізуйте свої досягнення"
        ));

        adapter = new OnboardingAdapter(items);
        viewPager.setAdapter(adapter);

        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {}).attach();
    }

    private void finishOnboarding() {
        SharedPreferences prefs = getSharedPreferences("WorkoutPlannerPrefs", MODE_PRIVATE);
        prefs.edit().putBoolean("isFirstLaunch", false).apply();

        startActivity(new Intent(this, UserProfileSetupActivity.class));
        finish();
    }

    public static class OnboardingItem {
        private int image;
        private String title;
        private String description;

        public OnboardingItem(int image, String title, String description) {
            this.image = image;
            this.title = title;
            this.description = description;
        }

        public int getImage() { return image; }
        public String getTitle() { return title; }
        public String getDescription() { return description; }
    }
}