package com.example.workoutplanner.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.example.workoutplanner.model.WorkoutPlan;
import java.util.List;

@Dao
public interface WorkoutPlanDao {

    @Insert
    long insert(WorkoutPlan plan);

    @Update
    void update(WorkoutPlan plan);

    @Delete
    void delete(WorkoutPlan plan);

    @Query("SELECT * FROM workout_plans ORDER BY created_date DESC")
    LiveData<List<WorkoutPlan>> getAllPlans();

    @Query("SELECT * FROM workout_plans WHERE user_id = :userId ORDER BY created_date DESC")
    LiveData<List<WorkoutPlan>> getPlansByUserId(int userId);

    @Query("SELECT * FROM workout_plans WHERE plan_id = :planId")
    LiveData<WorkoutPlan> getPlanById(int planId);

    @Query("SELECT * FROM workout_plans WHERE is_active = 1 AND user_id = :userId LIMIT 1")
    LiveData<WorkoutPlan> getActivePlan(int userId);

    @Query("UPDATE workout_plans SET is_active = 0 WHERE user_id = :userId")
    void deactivateAllPlans(int userId);
}