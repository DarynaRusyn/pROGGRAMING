package com.example.workoutplanner.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.workoutplanner.model.WorkoutHistory;
import com.example.workoutplanner.repository.WorkoutHistoryRepository;
import java.util.List;

public class WorkoutHistoryViewModel extends AndroidViewModel {

    private WorkoutHistoryRepository repository;
    private LiveData<List<WorkoutHistory>> allHistory;

    public WorkoutHistoryViewModel(@NonNull Application application) {
        super(application);
        repository = new WorkoutHistoryRepository(application);
        allHistory = repository.getAllHistory();
    }

    public void insert(WorkoutHistory history) {
        repository.insert(history);
    }

    public void update(WorkoutHistory history) {
        repository.update(history);
    }

    public void delete(WorkoutHistory history) {
        repository.delete(history);
    }

    public LiveData<List<WorkoutHistory>> getAllHistory() {
        return allHistory;
    }

    public LiveData<List<WorkoutHistory>> getHistoryByUserId(int userId) {
        return repository.getHistoryByUserId(userId);
    }

    public LiveData<WorkoutHistory> getHistoryById(int historyId) {
        return repository.getHistoryById(historyId);
    }

    public LiveData<Integer> getTotalWorkoutsCount(int userId) {
        return repository.getTotalWorkoutsCount(userId);
    }
}