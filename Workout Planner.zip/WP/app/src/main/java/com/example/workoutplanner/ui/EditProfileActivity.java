package com.example.workoutplanner.ui;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.workoutplanner.R;
import com.example.workoutplanner.database.AppDatabase;
import com.example.workoutplanner.model.User;
import com.example.workoutplanner.viewmodel.UserViewModel;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;

public class EditProfileActivity extends AppCompatActivity {

    private TextInputEditText etUserName;
    private MaterialAutoCompleteTextView spinnerGoal, spinnerLevel;
    private Button btnSave;
    private UserViewModel userViewModel;
    private User currentUser;
    private boolean isNewUser = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        etUserName = findViewById(R.id.etEditUserName);
        spinnerGoal = findViewById(R.id.spinnerEditGoal);
        spinnerLevel = findViewById(R.id.spinnerEditLevel);
        btnSave = findViewById(R.id.btnSaveProfile);

        setupSpinners();

        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);

        loadCurrentUser();

        btnSave.setOnClickListener(v -> saveProfile());

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Редагувати профіль");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void setupSpinners() {
        String[] goals = getResources().getStringArray(R.array.user_goals);
        ArrayAdapter<String> goalAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, goals);
        spinnerGoal.setAdapter(goalAdapter);

        String[] levels = getResources().getStringArray(R.array.experience_levels);
        ArrayAdapter<String> levelAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, levels);
        spinnerLevel.setAdapter(levelAdapter);
    }

    private void loadCurrentUser() {
        userViewModel.getCurrentUser().observe(this, user -> {
            if (user != null) {
                Log.d("EditProfile", "User loaded: " + user.getUserName());
                currentUser = user;
                isNewUser = false;
                etUserName.setText(user.getUserName());
                spinnerGoal.setText(user.getUserGoal(), false);
                spinnerLevel.setText(user.getExperienceLevel(), false);
            } else {
                Log.d("EditProfile", "No user found - creating new");
                isNewUser = true;
                // Залишаємо поля порожніми для нового користувача
            }
        });
    }

    private void saveProfile() {
        String userName = etUserName.getText().toString().trim();
        String goal = spinnerGoal.getText().toString().trim();
        String level = spinnerLevel.getText().toString().trim();

        Log.d("EditProfile", "Saving profile...");
        Log.d("EditProfile", "Name: " + userName);
        Log.d("EditProfile", "Goal: " + goal);
        Log.d("EditProfile", "Level: " + level);
        Log.d("EditProfile", "Is new user: " + isNewUser);

        if (userName.isEmpty()) {
            etUserName.setError("Введіть ім'я");
            return;
        }

        if (goal.isEmpty()) {
            Toast.makeText(this, "Оберіть мету тренувань", Toast.LENGTH_SHORT).show();
            return;
        }

        if (level.isEmpty()) {
            Toast.makeText(this, "Оберіть рівень підготовки", Toast.LENGTH_SHORT).show();
            return;
        }

        // ЯКЩО КОРИСТУВАЧА НЕМАЄ - СТВОРЮЄМО НОВОГО
        if (isNewUser || currentUser == null) {
            createNewUser(userName, goal, level);
        } else {
            updateExistingUser(userName, goal, level);
        }
    }

    private void createNewUser(String userName, String goal, String level) {
        Log.d("EditProfile", "Creating new user...");

        User newUser = new User(userName, goal, level, System.currentTimeMillis());

        new Thread(() -> {
            try {
                AppDatabase db = AppDatabase.getInstance(this);
                long userId = db.userDao().insert(newUser);

                Log.d("EditProfile", "New user created with ID: " + userId);

                // Зберігаємо ID користувача
                SharedPreferences prefs = getSharedPreferences("WorkoutPlannerPrefs", MODE_PRIVATE);
                prefs.edit()
                        .putLong("currentUserId", userId)
                        .putBoolean("profileSetupCompleted", true)
                        .apply();

                runOnUiThread(() -> {
                    Toast.makeText(this, "Профіль створено!", Toast.LENGTH_SHORT).show();
                    finish();
                });
            } catch (Exception e) {
                Log.e("EditProfile", "Error creating user", e);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Помилка створення: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void updateExistingUser(String userName, String goal, String level) {
        Log.d("EditProfile", "Updating existing user...");

        currentUser.setUserName(userName);
        currentUser.setUserGoal(goal);
        currentUser.setExperienceLevel(level);

        new Thread(() -> {
            try {
                AppDatabase db = AppDatabase.getInstance(this);
                db.userDao().update(currentUser);

                Log.d("EditProfile", "User updated successfully");

                runOnUiThread(() -> {
                    Toast.makeText(this, "Профіль оновлено!", Toast.LENGTH_SHORT).show();
                    finish();
                });
            } catch (Exception e) {
                Log.e("EditProfile", "Error updating user", e);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Помилка оновлення: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}