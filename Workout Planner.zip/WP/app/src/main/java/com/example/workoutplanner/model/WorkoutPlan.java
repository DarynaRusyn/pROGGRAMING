package com.example.workoutplanner.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;

@Entity(tableName = "workout_plans")
public class WorkoutPlan {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "plan_id")
    private int planId;

    @ColumnInfo(name = "plan_name")
    private String planName;

    @ColumnInfo(name = "plan_description")
    private String planDescription;

    @ColumnInfo(name = "duration_weeks")
    private int durationWeeks;

    @ColumnInfo(name = "days_per_week")
    private int daysPerWeek;

    @ColumnInfo(name = "created_date")
    private long createdDate;

    @ColumnInfo(name = "user_id")
    private int userId;

    @ColumnInfo(name = "is_active")
    private boolean isActive;

    public WorkoutPlan(String planName, String planDescription, int durationWeeks,
                       int daysPerWeek, long createdDate, int userId, boolean isActive) {
        this.planName = planName;
        this.planDescription = planDescription;
        this.durationWeeks = durationWeeks;
        this.daysPerWeek = daysPerWeek;
        this.createdDate = createdDate;
        this.userId = userId;
        this.isActive = isActive;
    }

    public int getPlanId() { return planId; }
    public void setPlanId(int planId) { this.planId = planId; }

    public String getPlanName() { return planName; }
    public void setPlanName(String planName) { this.planName = planName; }

    public String getPlanDescription() { return planDescription; }
    public void setPlanDescription(String planDescription) {
        this.planDescription = planDescription;
    }

    public int getDurationWeeks() { return durationWeeks; }
    public void setDurationWeeks(int durationWeeks) {
        this.durationWeeks = durationWeeks;
    }

    public int getDaysPerWeek() { return daysPerWeek; }
    public void setDaysPerWeek(int daysPerWeek) {
        this.daysPerWeek = daysPerWeek;
    }

    public long getCreatedDate() { return createdDate; }
    public void setCreatedDate(long createdDate) {
        this.createdDate = createdDate;
    }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
}