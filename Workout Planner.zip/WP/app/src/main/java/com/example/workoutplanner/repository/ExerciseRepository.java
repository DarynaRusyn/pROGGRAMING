package com.example.workoutplanner.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.workoutplanner.dao.ExerciseDao;
import com.example.workoutplanner.database.AppDatabase;
import com.example.workoutplanner.model.Exercise;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExerciseRepository {

    private ExerciseDao exerciseDao;
    private LiveData<List<Exercise>> allExercises;
    private ExecutorService executorService;

    public ExerciseRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        exerciseDao = database.exerciseDao();
        allExercises = exerciseDao.getAllExercises();
        executorService = Executors.newSingleThreadExecutor();
    }

    public void insert(Exercise exercise) {
        executorService.execute(() -> exerciseDao.insert(exercise));
    }

    public void update(Exercise exercise) {
        executorService.execute(() -> exerciseDao.update(exercise));
    }

    public void delete(Exercise exercise) {
        executorService.execute(() -> exerciseDao.delete(exercise));
    }

    public LiveData<List<Exercise>> getAllExercises() {
        return allExercises;
    }

    public LiveData<List<Exercise>> getExercisesByMuscleGroup(String muscleGroup) {
        return exerciseDao.getExercisesByMuscleGroup(muscleGroup);
    }

    public LiveData<List<Exercise>> getExercisesByEquipment(String equipment) {
        return exerciseDao.getExercisesByEquipment(equipment);
    }
}