package com.example.workoutplanner.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.ForeignKey;

@Entity(tableName = "workouts",
        foreignKeys = @ForeignKey(entity = User.class,
                parentColumns = "user_id",
                childColumns = "user_id",
                onDelete = ForeignKey.CASCADE))
public class Workout {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "workout_id")
    private int workoutId;

    @ColumnInfo(name = "workout_name")
    private String workoutName;

    @ColumnInfo(name = "workout_description")
    private String workoutDescription;

    @ColumnInfo(name = "duration")
    private int duration;

    @ColumnInfo(name = "difficulty")
    private String difficulty;

    @ColumnInfo(name = "created_date")
    private long createdDate;

    @ColumnInfo(name = "user_id")
    private int userId;

    public Workout(String workoutName, String workoutDescription,
                   int duration, String difficulty, long createdDate, int userId) {
        this.workoutName = workoutName;
        this.workoutDescription = workoutDescription;
        this.duration = duration;
        this.difficulty = difficulty;
        this.createdDate = createdDate;
        this.userId = userId;
    }

    public int getWorkoutId() { return workoutId; }
    public void setWorkoutId(int workoutId) { this.workoutId = workoutId; }

    public String getWorkoutName() { return workoutName; }
    public void setWorkoutName(String workoutName) {
        this.workoutName = workoutName;
    }

    public String getWorkoutDescription() { return workoutDescription; }
    public void setWorkoutDescription(String workoutDescription) {
        this.workoutDescription = workoutDescription;
    }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public long getCreatedDate() { return createdDate; }
    public void setCreatedDate(long createdDate) {
        this.createdDate = createdDate;
    }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
}