package com.example.workoutplanner.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.workoutplanner.R;
import com.example.workoutplanner.model.WorkoutHistory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {

    private List<WorkoutHistory> historyList;

    public void setHistoryList(List<WorkoutHistory> historyList) {
        this.historyList = historyList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_workout_history, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        WorkoutHistory history = historyList.get(position);
        holder.tvWorkoutName.setText(history.getWorkoutName());

        String formattedDate = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
                .format(new Date(history.getCompletedDate()));
        holder.tvDate.setText("Дата: " + formattedDate);

        holder.tvDuration.setText("Тривалість: " + history.getDurationMinutes() + " хв");

        String notes = history.getNotes();
        holder.tvNotes.setText("Нотатки: " + (notes == null || notes.isEmpty() ? "—" : notes));
    }

    @Override
    public int getItemCount() {
        return historyList != null ? historyList.size() : 0;
    }

    public static class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvWorkoutName, tvDate, tvDuration, tvNotes;

        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvWorkoutName = itemView.findViewById(R.id.tvWorkoutName);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvDuration = itemView.findViewById(R.id.tvDuration);
            tvNotes = itemView.findViewById(R.id.tvNotes);
        }
    }
}
