package com.example.workoutplanner.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;

@Entity(tableName = "workout_history")
public class WorkoutHistory {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "history_id")
    private int historyId;

    @ColumnInfo(name = "workout_id")
    private int workoutId;

    @ColumnInfo(name = "workout_name")
    private String workoutName;

    @ColumnInfo(name = "completed_date")
    private long completedDate;

    @ColumnInfo(name = "duration_minutes")
    private int durationMinutes;

    @ColumnInfo(name = "notes")
    private String notes;

    @ColumnInfo(name = "user_id")
    private int userId;

    public WorkoutHistory(int workoutId, String workoutName, long completedDate,
                          int durationMinutes, String notes, int userId) {
        this.workoutId = workoutId;
        this.workoutName = workoutName;
        this.completedDate = completedDate;
        this.durationMinutes = durationMinutes;
        this.notes = notes;
        this.userId = userId;
    }

    public int getHistoryId() { return historyId; }
    public void setHistoryId(int historyId) { this.historyId = historyId; }

    public int getWorkoutId() { return workoutId; }
    public void setWorkoutId(int workoutId) { this.workoutId = workoutId; }

    public String getWorkoutName() { return workoutName; }
    public void setWorkoutName(String workoutName) { this.workoutName = workoutName; }

    public long getCompletedDate() { return completedDate; }
    public void setCompletedDate(long completedDate) { this.completedDate = completedDate; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
}