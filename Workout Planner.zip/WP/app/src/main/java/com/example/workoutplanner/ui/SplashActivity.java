package com.example.workoutplanner.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.example.workoutplanner.MainActivity;
import com.example.workoutplanner.R;

public class SplashActivity extends AppCompatActivity {
    private static final int SPLASH_DURATION = 2000;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        prefs = getSharedPreferences("WorkoutPlannerPrefs", MODE_PRIVATE);

        new Handler().postDelayed(() -> {
            boolean isFirstLaunch = prefs.getBoolean("isFirstLaunch", true);

            Intent intent;
            if (isFirstLaunch) {
                intent = new Intent(SplashActivity.this, OnboardingActivity.class);
            } else {
                intent = new Intent(SplashActivity.this, MainActivity.class);
            }
            startActivity(intent);
            finish();
        }, SPLASH_DURATION);
    }
}