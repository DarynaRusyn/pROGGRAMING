package com.example.workoutplanner.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.example.workoutplanner.dao.ExerciseDao;
import com.example.workoutplanner.dao.UserDao;
import com.example.workoutplanner.dao.WorkoutDao;
import com.example.workoutplanner.dao.WorkoutHistoryDao;
import com.example.workoutplanner.dao.WorkoutPlanDao;
import com.example.workoutplanner.model.Exercise;
import com.example.workoutplanner.model.User;
import com.example.workoutplanner.model.Workout;
import com.example.workoutplanner.model.WorkoutHistory;
import com.example.workoutplanner.model.WorkoutPlan;

@Database(entities = {User.class, Exercise.class, Workout.class,
        WorkoutHistory.class, WorkoutPlan.class},
        version = 3,
        exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instance;

    public abstract UserDao userDao();
    public abstract ExerciseDao exerciseDao();
    public abstract WorkoutDao workoutDao();
    public abstract WorkoutHistoryDao workoutHistoryDao();
    public abstract WorkoutPlanDao workoutPlanDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "workout_planner_database"
                    )
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}