package com.example.workoutplanner.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.workoutplanner.R;
import com.example.workoutplanner.model.WorkoutHistory;
import com.example.workoutplanner.viewmodel.WorkoutHistoryViewModel;
import com.example.workoutplanner.viewmodel.WorkoutViewModel;

public class WorkoutDetailsActivity extends AppCompatActivity {

    public static final String EXTRA_WORKOUT_ID = "workoutId";

    private WorkoutViewModel viewModel;
    private WorkoutHistoryViewModel historyViewModel;
    private int workoutId;
    private Button btnStartWorkout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_details);

        workoutId = getIntent().getIntExtra(EXTRA_WORKOUT_ID, -1);

        if (workoutId == -1) {
            finish();
            return;
        }

        btnStartWorkout = findViewById(R.id.btn_start_workout);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Деталі тренування");
        }

        viewModel = new ViewModelProvider(this).get(WorkoutViewModel.class);
        historyViewModel = new ViewModelProvider(this).get(WorkoutHistoryViewModel.class);

        loadWorkoutDetails();

        btnStartWorkout.setOnClickListener(v -> startWorkout());
    }

    private void loadWorkoutDetails() {
        TextView tvWorkoutName = findViewById(R.id.text_view_workout_name_detail);
        TextView tvWorkoutDescription = findViewById(R.id.text_view_workout_description_detail);
        TextView tvDuration = findViewById(R.id.text_view_duration_detail);
        TextView tvDifficulty = findViewById(R.id.text_view_difficulty_detail);

        viewModel.getWorkoutById(workoutId).observe(this, workout -> {
            if (workout != null) {
                tvWorkoutName.setText(workout.getWorkoutName());
                tvWorkoutDescription.setText(workout.getWorkoutDescription());
                tvDuration.setText(workout.getDuration() + " хв");
                tvDifficulty.setText(workout.getDifficulty());

                if (getSupportActionBar() != null) {
                    getSupportActionBar().setTitle(workout.getWorkoutName());
                }
            }
        });
    }

    private void startWorkout() {
        viewModel.getWorkoutById(workoutId).observe(this, workout -> {
            if (workout != null) {
                // Додаємо запис до історії
                WorkoutHistory history = new WorkoutHistory(
                        workoutId,
                        workout.getWorkoutName(),
                        System.currentTimeMillis(),
                        workout.getDuration(),
                        "Тренування завершено",
                        1
                );

                historyViewModel.insert(history);

                Toast.makeText(this, "Тренування розпочато!", Toast.LENGTH_SHORT).show();

                // Можна додати таймер або перейти до іншого екрану
                finish();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}