package com.example.workoutplanner.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutplanner.R;
import com.example.workoutplanner.adapter.WorkoutAdapter;
import com.example.workoutplanner.viewmodel.WorkoutViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class WorkoutsFragment extends Fragment {

    private RecyclerView recyclerView;
    private WorkoutAdapter adapter;
    private WorkoutViewModel viewModel;
    private FloatingActionButton fabAdd;
    private static final int ADD_WORKOUT_REQUEST = 2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_workouts, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewWorkouts);
        fabAdd = view.findViewById(R.id.fabAddWorkout);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new WorkoutAdapter();
        adapter.setOnItemClickListener(workout -> {
            Intent intent = new Intent(getContext(), WorkoutDetailsActivity.class);
            intent.putExtra(WorkoutDetailsActivity.EXTRA_WORKOUT_ID, workout.getWorkoutId());
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(WorkoutViewModel.class);
        viewModel.getAllWorkouts().observe(getViewLifecycleOwner(), workouts -> {
            adapter.setWorkouts(workouts);
        });

        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), AddWorkoutActivity.class);
            startActivityForResult(intent, ADD_WORKOUT_REQUEST);
        });

        return view;
    }
}